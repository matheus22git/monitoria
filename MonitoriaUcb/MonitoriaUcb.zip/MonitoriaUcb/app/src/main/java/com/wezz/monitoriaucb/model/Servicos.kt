package com.wezz.monitoriaucb.model

data class Servicos(

    val img: Int? = null,
    val nome: String? = null

)
